// Registration + login + logout
const express = require('express');
const bcrypt = require('bcryptjs');
const pool = require('../config/db');

const router = express.Router();

// POST /api/auth/register
router.post('/register', async (req, res, next) => {
  try {
    const { name, birthday, email, password, securityQuestion, securityAnswer } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email and password are required' });
    }
    if (String(password).length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters' });
    }

    const [existing] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
    if (existing.length > 0) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    const hash = await bcrypt.hash(password, 10);
    const [result] = await pool.query(
      `INSERT INTO users (name, birthday, email, password_hash, security_question, security_answer)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [name, birthday || null, email, hash, securityQuestion || null, securityAnswer || null]
    );

    req.session.userId = result.insertId;
    req.session.role = 'user';
    res.status(201).json({ message: 'Registered successfully', userId: result.insertId });
  } catch (err) {
    next(err);
  }
});

// POST /api/auth/login
router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const user = rows[0];
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    await pool.query('UPDATE users SET last_seen = NOW() WHERE id = ?', [user.id]);

    req.session.userId = user.id;
    req.session.role = user.role;
    res.json({ message: 'Logged in', role: user.role });
  } catch (err) {
    next(err);
  }
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  req.session.destroy(() => res.json({ message: 'Logged out' }));
});

// GET /api/auth/me
router.get('/me', async (req, res, next) => {
  try {
    if (!req.session.userId) return res.status(401).json({ error: 'Not logged in' });
    const [rows] = await pool.query(
      'SELECT id, name, email, role, trial_start, is_paid FROM users WHERE id = ?',
      [req.session.userId]
    );
    res.json(rows[0] || null);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
