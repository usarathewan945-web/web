// Thumbnail editor backend: save/list/delete projects + import image by URL
const express = require('express');
const pool = require('../config/db');
const { requireLogin, checkTrial } = require('../middleware/auth');

const router = express.Router();

// GET /api/thumbnails  -> list current user's saved thumbnails
router.get('/', requireLogin, async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      'SELECT id, title, created_at FROM thumbnails WHERE user_id = ? ORDER BY created_at DESC',
      [req.session.userId]
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

// POST /api/thumbnails -> save a thumbnail project (requires active trial or paid)
router.post('/', requireLogin, checkTrial, async (req, res, next) => {
  try {
    if (req.trial.expired) {
      return res.status(402).json({ error: 'Free trial expired', redirect: '/payment.html' });
    }
    const { title, data } = req.body;
    const [result] = await pool.query(
      'INSERT INTO thumbnails (user_id, title, data) VALUES (?, ?, ?)',
      [req.session.userId, title || 'Untitled', data || '']
    );
    res.status(201).json({ message: 'Saved', id: result.insertId });
  } catch (err) {
    next(err);
  }
});

// DELETE /api/thumbnails/:id
router.delete('/:id', requireLogin, async (req, res, next) => {
  try {
    await pool.query('DELETE FROM thumbnails WHERE id = ? AND user_id = ?', [
      req.params.id,
      req.session.userId,
    ]);
    res.json({ message: 'Deleted' });
  } catch (err) {
    next(err);
  }
});

// GET /api/thumbnails/import?url=...  -> proxy/validate an external image URL
router.get('/import', requireLogin, async (req, res) => {
  const { url } = req.query;
  if (!url || !/^https?:\/\//i.test(url)) {
    return res.status(400).json({ error: 'A valid http(s) image URL is required' });
  }
  // Returned to the client which loads it into the canvas editor.
  res.json({ url });
});

module.exports = router;
