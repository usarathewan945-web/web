// Admin panel data: online users, trial usage, user summaries
const express = require('express');
const pool = require('../config/db');
const { requireLogin, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// GET /api/admin/summary
router.get('/summary', requireLogin, requireAdmin, async (req, res, next) => {
  try {
    const trialDays = parseInt(process.env.TRIAL_DAYS || '7', 10);

    const [[{ total }]] = await pool.query('SELECT COUNT(*) AS total FROM users');
    const [[{ online }]] = await pool.query(
      'SELECT COUNT(*) AS online FROM users WHERE last_seen >= (NOW() - INTERVAL 5 MINUTE)'
    );
    const [[{ paid }]] = await pool.query('SELECT COUNT(*) AS paid FROM users WHERE is_paid = 1');

    const [users] = await pool.query(
      `SELECT id, name, email, role, is_paid, trial_start, last_seen, created_at,
              DATEDIFF(NOW(), trial_start) AS trial_days_used
       FROM users ORDER BY created_at DESC`
    );

    const detailed = users.map((u) => ({
      ...u,
      trial_days_left: u.is_paid ? null : Math.max(0, trialDays - (u.trial_days_used || 0)),
      online: u.last_seen && new Date(u.last_seen) >= new Date(Date.now() - 5 * 60 * 1000),
    }));

    res.json({ totals: { total, online, paid }, trialDays, users: detailed });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
