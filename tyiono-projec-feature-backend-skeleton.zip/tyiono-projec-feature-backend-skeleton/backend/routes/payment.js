// Payment / checkout routes
// NOTE: real card processing is stubbed. Connect a real processor (Stripe/PayHere) where marked.
const express = require('express');
const pool = require('../config/db');
const { requireLogin } = require('../middleware/auth');

const router = express.Router();

// POST /api/payment/checkout
router.post('/checkout', requireLogin, async (req, res, next) => {
  try {
    const { cardNumber, expiry, cvc, name, amount } = req.body;
    if (!cardNumber || !expiry || !cvc || !name) {
      return res.status(400).json({ error: 'All card fields are required' });
    }

    const last4 = String(cardNumber).replace(/\s+/g, '').slice(-4);
    const charge = parseFloat(amount || '9.99');

    // --- CARD PROCESSING STUB -------------------------------------------
    // Replace this block with a real call to Stripe / PayHere, etc.
    const processed = { success: true };
    // --------------------------------------------------------------------

    const status = processed.success ? 'success' : 'failed';
    await pool.query(
      'INSERT INTO payments (user_id, amount, card_last4, status) VALUES (?, ?, ?, ?)',
      [req.session.userId, charge, last4, status]
    );

    if (processed.success) {
      await pool.query('UPDATE users SET is_paid = 1 WHERE id = ?', [req.session.userId]);
      return res.json({ message: 'Payment successful', status });
    }
    res.status(402).json({ error: 'Payment failed', status });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
