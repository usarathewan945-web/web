// Creates the database tables and a default admin account.
// Run once with: npm run init-db
require('dotenv').config();
const bcrypt = require('bcryptjs');
const pool = require('../config/db');

async function init() {
  // users table
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(120) NOT NULL,
      birthday DATE,
      email VARCHAR(190) NOT NULL UNIQUE,
      password_hash VARCHAR(255) NOT NULL,
      security_question VARCHAR(255),
      security_answer VARCHAR(255),
      role ENUM('user','admin') NOT NULL DEFAULT 'user',
      trial_start DATETIME DEFAULT CURRENT_TIMESTAMP,
      is_paid TINYINT(1) NOT NULL DEFAULT 0,
      last_seen DATETIME NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  // payments table (records of checkout attempts)
  await pool.query(`
    CREATE TABLE IF NOT EXISTS payments (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      amount DECIMAL(10,2) NOT NULL,
      card_last4 VARCHAR(4),
      status ENUM('pending','success','failed') NOT NULL DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  // thumbnails table (saved projects from the editor)
  await pool.query(`
    CREATE TABLE IF NOT EXISTS thumbnails (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      title VARCHAR(190),
      data LONGTEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  // create default admin
  const email = process.env.ADMIN_EMAIL || 'admin@tyiono.com';
  const password = process.env.ADMIN_PASSWORD || 'admin123';
  const [rows] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
  if (rows.length === 0) {
    const hash = await bcrypt.hash(password, 10);
    await pool.query(
      `INSERT INTO users (name, email, password_hash, role, is_paid)
       VALUES (?, ?, ?, 'admin', 1)`,
      ['Administrator', email, hash]
    );
    console.log('Default admin created:', email);
  } else {
    console.log('Admin already exists:', email);
  }

  console.log('Database initialised successfully.');
  process.exit(0);
}

init().catch((err) => {
  console.error('DB init failed:', err);
  process.exit(1);
});
