// Auth + trial middleware
const pool = require('../config/db');

function requireLogin(req, res, next) {
  if (req.session && req.session.userId) return next();
  return res.status(401).json({ error: 'Not logged in' });
}

function requireAdmin(req, res, next) {
  if (req.session && req.session.role === 'admin') return next();
  return res.status(403).json({ error: 'Admin access only' });
}

// Checks whether the logged-in user's free trial is still valid (or they have paid)
async function checkTrial(req, res, next) {
  try {
    const [rows] = await pool.query(
      'SELECT trial_start, is_paid FROM users WHERE id = ?',
      [req.session.userId]
    );
    if (rows.length === 0) return res.status(401).json({ error: 'User not found' });

    const user = rows[0];
    const trialDays = parseInt(process.env.TRIAL_DAYS || '7', 10);
    const start = new Date(user.trial_start);
    const expiry = new Date(start.getTime() + trialDays * 24 * 60 * 60 * 1000);
    const daysLeft = Math.ceil((expiry - new Date()) / (24 * 60 * 60 * 1000));

    req.trial = { expired: !user.is_paid && new Date() > expiry, daysLeft, isPaid: !!user.is_paid };
    next();
  } catch (err) {
    next(err);
  }
}

module.exports = { requireLogin, requireAdmin, checkTrial };
