# tyiono-project

A web app for creating YouTube thumbnails, frames and channel art. Includes a home page
with scroll animations, user registration/login, a 7-day free trial, a card-payment
checkout, an in-browser thumbnail editor, and an admin dashboard.

## Tech stack
- **Frontend:** plain HTML/CSS/JS (canvas-based editor, scroll animations)
- **Backend:** Node.js + Express
- **Database:** MySQL (via `mysql2`)
- **Auth:** `express-session` + `bcryptjs` password hashing

## Project structure
```
tyiono-project/
├─ frontend/
│  ├─ index.html        Home page (parallax, fade-in reveal, sticky scroll)
│  ├─ register.html     Sign up (name, birthday, email, 8-char password, security Q&A)
│  ├─ login.html        Login (validated against the database)
│  ├─ dashboard.html    Thumbnail editor + trial status
│  ├─ payment.html      Card checkout
│  ├─ admin.html        Admin panel (online users, trial usage, details)
│  ├─ css/style.css
│  └─ js/
└─ backend/
   ├─ server.js         Express entry point (also serves the frontend)
   ├─ config/db.js      MySQL connection pool
   ├─ models/initDb.js  Creates tables + default admin
   ├─ middleware/       Auth + trial checks
   ├─ routes/           auth, payment, thumbnails, admin
   ├─ .env.example
   └─ package.json
```

## Setup & run

1. **Get a MySQL database.** Use a local MySQL or a free online host
   (e.g. freesqldatabase.com, Railway, Aiven).

2. **Configure environment variables.**
   ```bash
   cd backend
   cp .env.example .env
   # edit .env with your DB host, user, password, name and a SESSION_SECRET
   ```

3. **Install dependencies.**
   ```bash
   npm install
   ```

4. **Create the tables and default admin.**
   ```bash
   npm run init-db
   ```
   This creates a default admin from `ADMIN_EMAIL` / `ADMIN_PASSWORD` in `.env`.

5. **Start the server.**
   ```bash
   npm start
   ```
   Open http://localhost:3000

## Notes
- **Payment is stubbed.** In `backend/routes/payment.js` look for the
  `CARD PROCESSING STUB` block and replace it with a real processor
  (Stripe, PayHere, etc.). No real card data is stored — only the last 4 digits.
- **External generation API:** `GENERATION_API_URL` / `GENERATION_API_KEY` in
  `.env` are placeholders for plugging in an image-generation/chat service later.
- Admin login uses the default admin credentials, then opens `admin.html`.

## Download the source
From the GitLab project page: **Code → Download source code → zip**.
