// Shared API helper (same-origin, sends session cookie)
const API = {
  async req(path, method = 'GET', body) {
    const opts = { method, credentials: 'include', headers: {} };
    if (body) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
    const res = await fetch('/api' + path, opts);
    let data = null;
    try { data = await res.json(); } catch (e) {}
    if (!res.ok) throw Object.assign(new Error((data && data.error) || 'Request failed'), { status: res.status, data });
    return data;
  },
  get(p){return this.req(p);},
  post(p,b){return this.req(p,'POST',b);},
  del(p){return this.req(p,'DELETE');},
};
