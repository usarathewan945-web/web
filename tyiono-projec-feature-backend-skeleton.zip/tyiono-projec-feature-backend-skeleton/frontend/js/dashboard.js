// Dashboard: trial status, thumbnail editor (canvas), save/list/download
let img = null;
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const texts = [];

function filterString(){
  const b = document.getElementById('brightness').value;
  const c = document.getElementById('contrast').value;
  const s = document.getElementById('saturate').value;
  const f = document.getElementById('filter').value;
  let str = `brightness(${b}%) contrast(${c}%) saturate(${s}%)`;
  if (f !== 'none') str += ' ' + f;
  return str;
}

function draw(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle = '#000';
  ctx.fillRect(0,0,canvas.width,canvas.height);
  if (img){
    ctx.filter = filterString();
    ctx.drawImage(img,0,0,canvas.width,canvas.height);
    ctx.filter = 'none';
  }
  texts.forEach(t => {
    ctx.font = 'bold 70px Segoe UI, Arial';
    ctx.fillStyle = t.color;
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 6;
    ctx.strokeText(t.value, t.x, t.y);
    ctx.fillText(t.value, t.x, t.y);
  });
}

['brightness','contrast','saturate','filter'].forEach(id =>
  document.getElementById(id).addEventListener('input', draw));

document.getElementById('fileInput').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => loadImage(reader.result);
  reader.readAsDataURL(file);
});

function loadImage(src){
  const i = new Image();
  i.crossOrigin = 'anonymous';
  i.onload = () => { img = i; draw(); };
  i.onerror = () => alert('Could not load image (the site may block external loading).');
  i.src = src;
}

document.getElementById('importBtn').addEventListener('click', async () => {
  const url = prompt('Paste an image URL:');
  if (!url) return;
  try {
    const data = await API.get('/thumbnails/import?url=' + encodeURIComponent(url));
    loadImage(data.url);
  } catch (err) { alert(err.message); }
});

document.getElementById('cropBtn').addEventListener('click', draw);

document.getElementById('stickerText').addEventListener('click', () => {
  const value = prompt('Text to add:');
  if (!value) return;
  texts.push({ value, x: 80, y: 360, color: document.getElementById('textColor').value });
  draw();
});

document.getElementById('downloadBtn').addEventListener('click', () => {
  const a = document.createElement('a');
  a.download = 'thumbnail.png';
  a.href = canvas.toDataURL('image/png');
  a.click();
});

document.getElementById('saveBtn').addEventListener('click', async () => {
  try {
    const title = prompt('Title for this thumbnail:', 'My thumbnail') || 'Untitled';
    await API.post('/thumbnails', { title, data: canvas.toDataURL('image/png') });
    alert('Saved!');
    loadSaved();
  } catch (err) {
    if (err.status === 402) { alert('Your free trial has expired. Please upgrade.'); window.location.href = 'payment.html'; }
    else alert(err.message);
  }
});

async function loadSaved(){
  try {
    const list = await API.get('/thumbnails');
    const el = document.getElementById('saved');
    el.innerHTML = '<h2>My thumbnails</h2>' + (list.length
      ? '<ul>' + list.map(t => `<li>${t.title} <small>(${new Date(t.created_at).toLocaleString()})</small></li>`).join('') + '</ul>'
      : '<p>No saved thumbnails yet.</p>');
  } catch (e) {}
}
document.getElementById('savedLink').addEventListener('click', (e)=>{e.preventDefault();loadSaved();});

document.getElementById('logoutBtn').addEventListener('click', async (e) => {
  e.preventDefault();
  await API.post('/auth/logout');
  window.location.href = 'login.html';
});

(async function(){
  try {
    const me = await API.get('/auth/me');
    const trialDays = 7;
    const start = new Date(me.trial_start);
    const left = me.is_paid ? null : Math.max(0, trialDays - Math.floor((Date.now() - start) / 86400000));
    const banner = document.getElementById('trial');
    if (me.is_paid) { banner.textContent = 'Pro account — unlimited access.'; }
    else if (left > 0) { banner.textContent = `Free trial: ${left} day(s) left.`; }
    else { banner.className = 'trial-banner expired'; banner.innerHTML = 'Your free trial has expired. <a href="payment.html">Upgrade now</a>.'; }
    draw();
    loadSaved();
  } catch (err) {
    window.location.href = 'login.html';
  }
})();
