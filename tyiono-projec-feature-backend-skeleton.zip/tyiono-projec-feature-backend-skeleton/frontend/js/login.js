// Login logic
document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = document.getElementById('msg');
  const f = e.target;
  try {
    const data = await API.post('/auth/login', { email: f.email.value, password: f.password.value });
    msg.className = 'msg ok'; msg.textContent = 'Logged in! Redirecting...';
    const dest = data.role === 'admin' ? 'admin.html' : 'dashboard.html';
    setTimeout(() => (window.location.href = dest), 600);
  } catch (err) {
    msg.className = 'msg error'; msg.textContent = err.message;
  }
});
