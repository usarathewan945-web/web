// Scroll-triggered animations: parallax + reveal (fade, zoom, slide)
(function(){
  // Parallax on hero background
  const parallax = document.querySelector('.parallax');
  if (parallax) {
    window.addEventListener('scroll', () => {
      const y = window.scrollY;
      parallax.style.transform = `translateY(${y * 0.35}px)`;
    }, { passive: true });
  }

  // Reveal on scroll using IntersectionObserver (handles .reveal, .reveal-zoom, .reveal-left, .reveal-right)
  const reveals = document.querySelectorAll('.reveal, .reveal-zoom, .reveal-left, .reveal-right');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          e.target.classList.add('visible');
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.12 });
    reveals.forEach((el) => io.observe(el));
  } else {
    reveals.forEach((el) => el.classList.add('visible'));
  }
})();
