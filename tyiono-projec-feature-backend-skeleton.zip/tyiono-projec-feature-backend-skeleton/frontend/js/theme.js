// Theme (dark/light) toggle + live clock - shared across all pages
(function(){
  // Apply saved theme
  const saved = localStorage.getItem('tyiono-theme') || 'dark';
  if (saved === 'light') document.documentElement.setAttribute('data-theme', 'light');

  function iconFor(theme){ return theme === 'light' ? '\u2600\uFE0F' : '\uD83C\uDF19'; }

  window.toggleTheme = function(){
    const cur = document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
    const next = cur === 'light' ? 'dark' : 'light';
    if (next === 'light') document.documentElement.setAttribute('data-theme', 'light');
    else document.documentElement.removeAttribute('data-theme');
    localStorage.setItem('tyiono-theme', next);
    document.querySelectorAll('.theme-toggle').forEach(b => b.textContent = iconFor(next));
  };

  // Live clock - updates every second
  function tick(){
    const now = new Date();
    const t = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    document.querySelectorAll('.clock').forEach(el => el.textContent = t);
  }

  document.addEventListener('DOMContentLoaded', function(){
    const theme = document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
    document.querySelectorAll('.theme-toggle').forEach(b => {
      b.textContent = iconFor(theme);
      b.addEventListener('click', window.toggleTheme);
    });
    tick();
    setInterval(tick, 1000);
  });
})();
