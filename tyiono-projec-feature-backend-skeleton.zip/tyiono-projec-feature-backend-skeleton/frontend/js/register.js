// Registration logic
document.getElementById('registerForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = document.getElementById('msg');
  const f = e.target;
  const password = f.password.value;
  if (password.length < 8) {
    msg.className = 'msg error'; msg.textContent = 'Password must be at least 8 characters.';
    return;
  }
  try {
    await API.post('/auth/register', {
      name: f.name.value,
      birthday: f.birthday.value,
      email: f.email.value,
      password,
      securityQuestion: f.securityQuestion.value,
      securityAnswer: f.securityAnswer.value,
    });
    msg.className = 'msg ok'; msg.textContent = 'Registered! Redirecting...';
    setTimeout(() => (window.location.href = 'dashboard.html'), 800);
  } catch (err) {
    msg.className = 'msg error'; msg.textContent = err.message;
  }
});
