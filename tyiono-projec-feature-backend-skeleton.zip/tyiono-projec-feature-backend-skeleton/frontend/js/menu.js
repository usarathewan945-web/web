// Mobile slide-in menu (hamburger) - slides from the right
(function(){
  document.addEventListener('DOMContentLoaded', function(){
    const burger = document.getElementById('burger');
    const menu = document.getElementById('mobileMenu');
    const overlay = document.getElementById('menuOverlay');
    if (!burger || !menu) return;

    function open(){ menu.classList.add('open'); if(overlay) overlay.classList.add('show'); }
    function close(){ menu.classList.remove('open'); if(overlay) overlay.classList.remove('show'); }

    burger.addEventListener('click', open);
    if (overlay) overlay.addEventListener('click', close);
    menu.querySelectorAll('a').forEach(a => a.addEventListener('click', close));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
  });
})();
